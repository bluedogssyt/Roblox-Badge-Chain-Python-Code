# TRIO BADGE CHAIN SCRIPT <<<
# Credits: Doritogon303, LuckyToShine

# Max places per group.
max_places = 10

# Print Exceptions (errors). Highly not recommended.
print_errors = False

# List of groups.
groups = [000, 000, 000]

# Badge info.
badge_name = "Badge Chain"
badge_description = ""
badge_image = "placeholder.png"

# Chain place info.
place_name = "Chain Place"
place_description = ""

# Cookies.
cookies = open("cookies.txt").read().splitlines()

# HOW TO USE THIS SCRIPT!!!

# STEP 1:
# Create as many groups as you can (or use existing throwaway groups you own). Make sure each group's admin all ASSETS and OPEN CLOUD permissions are all set to true.
# Make all of the groups have Manual Approval turned on. (This is important since it will skip the CAPTCHA, saving a lot of time)

# STEP 2:
# Join all of the groups with your accounts.
# MAKE SURE all of the accounts have joined over 3 years ago for maximum speeds. (55 badges / minute per account).
# If you use new accounts, the speed will be (10 badges / minute per account).
# After that, collect all of the .ROBLOSECURITY tokens from the accounts.
# After you get a .ROBLOSECURITY from one of the accounts, DO NOT LOG OUT NORMALLY! Delete all of your roblox cookies to log out.

# STEP 3:
# List all of your .ROBLOSECURITY cookies in the 'cookies.txt' file. Make sure they are seperated by a new line.
# Once you are done, go to the groups on your main account and start accepting all of your alts into the groups. Make sure to rank them up to Admin.
# Now, PLEASE, transfer all of your groups to a group holder account. You have a HIGH CHANCE of getting banned if you don't.

# STEP 4:
# Make sure you set the 'max_places' to something reasonable before entering this step.
# A reasonable number would be...
# (badges made per hour) * (the amount of hours you are willing to spend per day) / (number of groups * 5)
# Now that you have put a REASONABLE number, let's move on.

# Start running the script 'main.py' to begin making places.
# Once the script finishes, delete all of the numbered files (group ids), 'allgames' and 'alluniverses'.
# Run the script again. Run it as many times until every place is made. You would know once the processing bar finishes instantly.

# STEP 5:
# Now, it's time to create a custom badge chain script.
# Use this model, and follow the steps within the script: https://create.roblox.com/store/asset/17806321571/Badge-Chain-Script
# After that, open up 'place.rbxl'. You will see a script. Change the number within the require() function to your own script. Then, save the place to file.
# PLEASE keep the chain place with as little detail as possible. Don't add anything. Unless you wanna be false banned!

# STEP 6:
# Being running 'updater.py'. Remember, the Rate Limit for creating places is (10 per minute per IP ADDRESS).
# Don't worry, it will save your progress even if you stop the script. Keep running it until every place is created.

# STEP 6.5:
# Make sure to test the chain before you continue! Make some test badges in a few chain places to test it out.

# STEP 7:
# If everything is working perfectly, it's time for the part you have been waiting for the most. The badge creating.
# Start running the script 'badges.py'. You can also run this script and the 'updater.py' script at the same time also.

# And that's all! You have created a badge chain!

# STEP 8: (optional)
# If you want to know how many badges your badge chain has, run the script 'countbadges.py'.
# The final number it inputs is the number of badges your badge chain has.