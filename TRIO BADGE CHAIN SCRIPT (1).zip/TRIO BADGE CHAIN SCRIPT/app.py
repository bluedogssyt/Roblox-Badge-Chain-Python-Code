import aiohttp, aiofiles, asyncio, random
from settings import *

class Account:
    def __init__(self, cookie):
        self.cookie = cookie
        self.xsrf_token = "None"
        self.id = None
        self.username = None

    async def get_xcsrf_token(self, session):
        while True:
            try:
                response = await session.post("https://catalog.roblox.com/")
                self.xsrf_token = response.headers.get("x-csrf-token")
                return response.headers.get("x-csrf-token")
            except Exception as e:
                if print_errors == True:
                    print(f"Get xcsrf token | {e}")
                await asyncio.sleep(5)

    async def get_account_info(self, session):
        while True:
            try:
                response = await session.get("https://users.roblox.com/v1/users/authenticated")
                if response.status == 200:
                    data = await response.json()
                    self.id = data["id"]
                    self.username = data["name"]
                    return "Success"
                else:
                    print(f"Failed to fetch account info. Status code: {response.status}")
                    print(self.cookie)
                    raise(f"Failed to fetch account info. Status code: {response.status}")
            except Exception as e:
                if print_errors == True:
                    print(f"Get Account Info | {e}")
                await asyncio.sleep(5)
            

async def create_universe(session:aiohttp.ClientSession, account:Account, groupid):
    while True:
        try:
            response = await session.post(f"https://apis.roblox.com/universes/v1/universes/create?groupid={groupid}",
                json = {"templatePlaceId": 95206881},
                headers = {"x-csrf-token": account.xsrf_token, "Content-Type": "application/json","User-Agent": "Roblox/WinInet","Origin": "https://www.roblox.com/","Referer": "https://www.roblox.com/"})
            
            if response.status == 200:
                json = await response.json()
                universeid = json.get("universeId")
                placeid = json.get("rootPlaceId")
                return (universeid, placeid)
            elif response.status == 403:
                await account.get_xcsrf_token(session)
            
            if print_errors == True:
                print(f"Create Universe | {account.username} | {response.status}")
            await asyncio.sleep(5)
        except Exception as e:
            if print_errors == True:
                print(f"Create Universe | {account.username} | {e}")
            await asyncio.sleep(5)


async def public_universe(session:aiohttp.ClientSession, account:Account, universe_id):
    while True:
        try:
            response = await session.post(f"https://develop.roblox.com/v1/universes/{universe_id}/activate",
                headers = {"x-csrf-token": account.xsrf_token})
            if response.status == 200:
                return
            elif response.status == 403:
                await account.get_xcsrf_token(session)
            
            if print_errors == True:
                print(f"Public Universe | {account.username} | {response.status}")
            await asyncio.sleep(5)
        except Exception as e:
            if print_errors == True:
                print(f"Public Universe | {account.username} | {e}")
            await asyncio.sleep(5)


async def change_size(session:aiohttp.ClientSession, account:Account, place_id, i):
    while True:
        try:
            response = await session.patch(f"https://develop.roblox.com/v2/places/{place_id}", json={"name": f"{place_name} {i}", "description": place_description, "maxPlayerCount": 1},
                headers = {"x-csrf-token": account.xsrf_token, "Content-Type": "application/json"})
            if response.status == 200:
                return
            elif response.status == 403:
                await account.get_xcsrf_token(session)
            
            if print_errors == True:
                print(f"Change Size | {account.username} | {response.status}")
            await asyncio.sleep(5)
        except Exception as e:
            if print_errors == True:
                print(f"Change Size | {account.username} | {e}")
            await asyncio.sleep(5)


async def change_permissions(session:aiohttp.ClientSession, account:Account, universe_id, i):
    while True:
        try:
            response = await session.patch(f"https://develop.roblox.com/v2/universes/{universe_id}/configuration", json={"name": f"{place_name} {i}","description": place_description, "studioAccessToApisAllowed": True, "permissions": {"IsThirdPartyTeleportAllowed": True, "IsThirdPartyAssetAllowed": True, "IsThirdPartyPurchaseAllowed": True}},
                headers = {"x-csrf-token": account.xsrf_token, "Content-Type": "application/json"})
            if response.status == 200:
                return
            elif response.status == 403:
                await account.get_xcsrf_token(session)
            elif response.status == 400:
                i = ""
                continue
            
            if print_errors == True:
                print(f"Change Permissions | {account.username} | {response.status}")
            await asyncio.sleep(5)
        except Exception as e:
            if print_errors == True:
                print(f"Change Permissions | {account.username} | {e}")
            await asyncio.sleep(5)


async def create_badge(session:aiohttp.ClientSession, account:Account, universe_id, badgedata):
    while True:
        try:
            check = await session.get(f"https://badges.roblox.com/v1/universes/{universe_id}/free-badges-quota")
            if check.status == 200:
                json = await check.json()
                if json == 0:
                    return
            
            data = aiohttp.FormData()

            file = await aiofiles.open(badge_image, "rb")
            data.add_field('upload_file', file, filename=badge_image)
            for key, value in badgedata.items():
                data.add_field(key, str(value))
                    
            response = await session.post(f"https://badges.roblox.com/v1/universes/{universe_id}/badges", data=data,
                headers = {"x-csrf-token": account.xsrf_token})
            if response.status == 200:
                json = await response.json()
                #print(json.get("id"))
                return json.get("id")
            elif response.status == 403:
                await account.get_xcsrf_token(session)
            try:
                j = await response.json()
                if j.get("errors"):
                    if j.get("errors")[0].get("code") == 18: return
            except: pass

            if print_errors == True:
                print(f"Create Badge | {account.username} | {response.status} | {universe_id}")
            await asyncio.sleep(5)
        except Exception as e:
            if print_errors == True:
                print(f"Create Badge | {account.username} | {e}  | {universe_id}")
            await asyncio.sleep(5)

async def count_badges(session:aiohttp.ClientSession, universe_id):
    cursor = ""
    amount = 0
    while cursor != None:
        try:       
            response = await session.get(f"https://badges.roblox.com/v1/universes/{universe_id}/badges?limit=100&cursor={cursor}&sortOrder=Asc")
            if response.status == 200:
                json = await response.json()
                amount += len(json.get("data"))
                cursor = json.get("nextPageCursor")
                #print(f"Counted: {amount}")
                continue
            try:
                j = await response.json()
                #print(j)
            except: pass

            if print_errors == True:
                print(f"Get badges | {universe_id} | {response.status}")
            await asyncio.sleep(5)
        except Exception as e:
            if print_errors == True:
                print(f"Get badges | {universe_id} | {e}")
            await asyncio.sleep(5)
    return amount


async def create_key(session:aiohttp.ClientSession, account, groupid, pool):
    while True:
        try:
            json = {"groupId": groupid, "cloudAuthUserConfiguredProperties": {"allowedCidrs": ["0.0.0.0/0"], "description": "", "isEnabled": True,
                    "name": ''.join(random.choice("dogcathorsedolphin") for _ in range(10)),
                    "scopes": []}}
            for game in pool:
                scope = {"scopeType": "universe-places","targetParts": [f"{game[0]}"],"operations": ["write"]}
                json["cloudAuthUserConfiguredProperties"]["scopes"].append(scope)

            response = await session.post("https://apis.roblox.com/cloud-authentication/v1/apiKey", json=json,
                headers = {"x-csrf-token": account.xsrf_token})
            if response.status == 200:
                json = await response.json()
                return json
            elif response.status == 403:
                await account.get_xcsrf_token(session)

            if print_errors == True:
                print(f"Create Key | {account.username} | {response.status}")
            await asyncio.sleep(5)
        except Exception as e:
            if print_errors == True:
                print(f"Create Key | {account.username} | {e}")
            await asyncio.sleep(5)


async def delete_key(session:aiohttp.ClientSession, account, key):
    while True:
        try:
            response = await session.delete(f"https://apis.roblox.com/cloud-authentication/v1/apiKey/{key}",
                headers = {"x-csrf-token": account.xsrf_token})
            if response.status == 200:
                json = await response.json()
                return json
            elif response.status == 403:
                await account.get_xcsrf_token(session)
                continue
            elif response.status == 404:
                return
            
            if print_errors == True:
                print(f"Delete Key | {account.username} | {response.status}")
            await asyncio.sleep(5)
        except Exception as e:
            if print_errors == True:
                print(f"Delete Key | {account.username} | {e}")
            await asyncio.sleep(5)


async def create_place(session:aiohttp.ClientSession, key, universe_id, place_id):
    while True:
        try:    
            file = await aiofiles.open("place.rbxl", "rb")
            aifile = await file.read()
                        
            response = await session.post(f"https://apis.roblox.com/universes/v1/{universe_id}/places/{place_id}/versions?versionType=Published", data=aifile,
                headers = {"x-api-key": key, "Content-Type": "application/octet-stream"})
            if response.status == 200:
                json = await response.json()
                return json
            try:
                j = await response.json()
                if print_errors == True:
                    print(j)
            except: pass
            if print_errors == True:
                print(f"Create Place | {place_id} | {response.status}")
            await asyncio.sleep(5)
        except Exception as e:
            if print_errors == True:
                print(f"Create Place | {place_id} | {e}")
            await asyncio.sleep(5)


async def get_games(session:aiohttp.ClientSession, group_id):
    cursor = ""
    pool = []
    while cursor != None:
        try:       
            response = await session.get(f"https://games.roblox.com/v2/groups/{group_id}/games?accessFilter=1&limit=100&cursor={cursor}&sortOrder=Asc")
            if response.status == 200:
                json = await response.json()
                for game in json.get("data"):
                    if game.get("rootPlace").get("id") < 6135875503 and game.get("rootPlace").get("id") > 6135876503: continue
                    pool.append((game.get("id"), game.get("rootPlace").get("id")))
                cursor = json.get("nextPageCursor")
                print(f"Counted: {len(pool)}")
                if len(pool) > max_places:
                    cursor = None
                continue
            try:
                j = await response.json()
                print(j)
            except: pass
            if print_errors == True:
                print(f"Get games | {group_id} | {response.status}")
            await asyncio.sleep(5)
        except Exception as e:
            if print_errors == True:
                print(f"Get games | {group_id} | {e}")
            await asyncio.sleep(5)
    return pool