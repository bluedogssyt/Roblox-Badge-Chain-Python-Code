import aiohttp, asyncio, time
from app import *
from tqdm.asyncio import tqdm
from operator import itemgetter

progress_bar = tqdm(total=max_places*len(groups), desc="Processing", unit="task")

async def main():
    account = Account(cookies[0])
    async with aiohttp.ClientSession(cookies={".ROBLOSECURITY": account.cookie}) as session:
        await account.get_account_info(session)
        await account.get_xcsrf_token(session)
        games = []
        for group in groups:
            async with aiofiles.open(f"{group}", "r") as file:
                grouptext = await file.readlines()
                for groupline in grouptext:
                    if groupline == "\n": continue
                    groupsplit = groupline.split(":")
                    games.append((int(groupsplit[0]), int(groupsplit[1]), int(group)))

        games = sorted(games, key=itemgetter(1))
        amountofplaces = 0

        try:
            async with aiofiles.open(f"savedplaces", "r") as file:
                fileread = await file.read()
                amountofplaces = int(fileread)
        except:
            async with aiofiles.open(f"savedplaces", "w") as file:
                await file.write("0")
        
        progress_bar.update(amountofplaces-1)

        for i in range(len(games)):
            if i >= amountofplaces:
                if games[i][1] < 6135875503 and games[i][1] > 6135876503: continue
                t1 = time.time()
                
                await public_universe(session, account, games[i][0])
                await change_size(session, account, games[i][1], i+1)
                await change_permissions(session, account, games[i][0], i+1)

                keyInfo = await create_key(session, account, games[i][2], [games[i]])
                await create_place(session, keyInfo.get("apikeySecret"), games[i][0], games[i][1])
                await delete_key(session, account, keyInfo.get("cloudAuthInfo").get("id"))

                t2 = time.time()
                trem = t2-t1
                
                progress_bar.update(1)

                print(f"place: {games[i][1]} | {i}/252000 ({round((252000-i)*trem)}) {games[i][2]}")

                async with aiofiles.open(f"savedplaces", "w") as file:
                    await file.write(str(i))


asyncio.run(main())