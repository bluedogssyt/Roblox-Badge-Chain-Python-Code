import aiohttp, asyncio
from app import *
from tqdm.asyncio import tqdm

progress_bar = tqdm(total=max_places*len(groups), desc="Processing", unit="task")
counted_games = 0
pool = {}

async def account_worker(cookie):
    global counted_games
    global pool

    while counted_games != len(groups):
        continue

    account = Account(cookie)
    async with aiohttp.ClientSession(cookies={".ROBLOSECURITY": account.cookie}) as session:
        await account.get_account_info(session)
        await account.get_xcsrf_token(session)

        for groupid in groups:
            games = len(open(f"{groupid}").read().splitlines())
            #print(f"games: {games} group: {groupid}")
            pool[str(groupid)] = games
            if max_places - games > 0:
                while pool[str(groupid)] <= max_places:
                    if pool[str(groupid)] <= max_places:
                        data = await create_universe(session, account, groupid)
                        universeid = data[0]
                        placeid = data[1]

                        tasks = []
                        tasks.append(public_universe(session, account, universeid))
                        tasks.append(change_size(session, account, placeid, ""))
                        tasks.append(change_permissions(session, account, universeid, ""))
                        #for _ in range(5):
                            #tasks.append(create_badge(session, account, universeid))
                        await asyncio.gather(*tasks)
                        #print(f"places: {pool[str(groupid)]} group: {groupid}")
                        pool[str(groupid)] += 1
                        progress_bar.update(1)

async def count_games(cookie, groupid):
    global counted_games
    account = Account(cookie)
    async with aiohttp.ClientSession(cookies={".ROBLOSECURITY": account.cookie}) as session:
        games = []
        try:
            async with aiofiles.open(f"{groupid}", "r") as file:
                grouptext = await file.readlines()
                for groupline in grouptext:
                    if groupline == "\n": continue
                    groupsplit = groupline.split(":")
                    games.append((int(groupsplit[0]), int(groupsplit[1])))
        except Exception as e:
            print(f"Failed to find {groupid} txt | {e}")
            games = await get_games(session, groupid)
            games.sort()
            async with aiofiles.open(f"{groupid}", "w") as file:
                nl = "\n"
                for game in games:
                    if game[0] < 6135875503 and game[0] > 6135876503: continue
                    await file.write(f"{game[0]}:{game[1]}{nl}")
            print(f"Save games to {groupid} txt")

        if len(games) > max_places:
            games.sort()
            games = games[:max_places]
            async with aiofiles.open(f"{groupid}", "w") as file:
                nl = "\n"
                for game in games:
                    await file.write(f"{game[0]}:{game[1]}{nl}")
        counted_games += 1
        progress_bar.update(len(games))

async def get_all_games():
    global counted_games

    while counted_games != len(groups):
        continue

    alluniverses = ""
    allgames = ""

    allulist = []
    allglist = []

    for groupid in groups:
        async with aiofiles.open(f"{groupid}", "r") as file:
            grouptext = await file.readlines()
            for groupline in grouptext:
                if groupline == "\n": continue
                groupsplit = groupline.split(":")
                allulist.append(str(groupsplit[0]))
                allglist.append(str(groupsplit[1][:-1]))
        print(f"Done counting group: {groupid}")

    allulist.sort()
    allglist.sort()

    alluniverses = ','.join(str(x) for x in allulist)
    
    print("Done making list: alluniverses")

    allgames = ','.join(str(x) for x in allglist)

    print("Done making list: allgames")
    
    async with aiofiles.open("alluniverses", "w") as file:
        await file.write(alluniverses)

    async with aiofiles.open("allgames", "w") as file:
        await file.write(allgames)
        
async def main():
    tasks = []
    for cookie in cookies:
        tasks.append(account_worker(cookie))
    await asyncio.gather(*tasks)

async def count_groups():
    tasks = []
    for groupid in groups:
        tasks.append(count_games(random.choice(cookies), groupid))
    await asyncio.gather(*tasks)

async def thing():
    tasks = []
    tasks.append(get_all_games())
    await asyncio.gather(*tasks)

asyncio.run(count_groups())
asyncio.run(thing())
asyncio.run(main())

print("All done creating games. Rerun the script to get a list of all games. (delete all of the files first)")