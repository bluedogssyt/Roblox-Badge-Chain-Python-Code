import aiohttp, asyncio, time
from app import *
from tqdm.asyncio import tqdm
from operator import itemgetter

badgedata = {"name": badge_name, "description": badge_description, "paymentSourceType": "Group", "expectedCost": 0}
progress_bar = tqdm(total=max_places*5*len(groups), desc="Processing", unit="task")

async def account_worker(cookie, games):
    account = Account(cookie)
    async with aiohttp.ClientSession(cookies={".ROBLOSECURITY": account.cookie}) as session:
        await account.get_account_info(session)
        await account.get_xcsrf_token(session)

        for game in games:
            universeid = game[0]
            tasks = []

            for _ in range(5):
                tasks.append(create_badge(session, account, universeid, badgedata))
            await asyncio.gather(*tasks)

            progress_bar.update(5)

async def main():
    games = []
    for groupid in groups:
        async with aiofiles.open(f"{groupid}", "r") as file:
            grouptext = await file.readlines()
            for groupline in grouptext:
                if groupline == "\n": continue
                groupsplit = groupline.split(":")
                games.append((int(groupsplit[0]), int(groupsplit[1])))
        print(f"Done counting group: {groupid}")

    time.sleep(1)

    games = sorted(games, key=itemgetter(1))
    
    chunki = round(len(games)/len(cookies)/2)
    chunks = [games[i:i + chunki] for i in range(0, len(games), chunki)]
    
    altvar = 0

    tasks = []
    for i in range(len(chunks)):
        tasks.append(account_worker(cookies[altvar], chunks[i]))
        altvar += 1
        if altvar == len(cookies):
            altvar = 0
    await asyncio.gather(*tasks)

asyncio.run(main())