import aiohttp, asyncio, time
from app import *
from tqdm.asyncio import tqdm

progress_bar = tqdm(total=max_places*len(groups), desc="Processing", unit="task")
amountofbadges = 0

async def count_split(cookie, games):
    global amountofbadges
    account = Account(cookie)
    async with aiohttp.ClientSession(cookies={".ROBLOSECURITY": account.cookie}) as session:
        for game in games:
            universeid = game[0]
            info = await count_badges(session, universeid)
            amountofbadges += info
            progress_bar.update(1)
        print(amountofbadges)

async def main():
    games = []
    for groupid in groups:
        async with aiofiles.open(f"{groupid}", "r") as file:
            grouptext = await file.readlines()
            for groupline in grouptext:
                if groupline == "\n": continue
                groupsplit = groupline.split(":")
                games.append((int(groupsplit[0]), int(groupsplit[1])))
        print(f"Done counting group: {groupid}")

    time.sleep(1)
    
    chunki = 250 # Don't make this too low or high.
    chunks = [games[i:i + chunki] for i in range(0, len(games), chunki)]

    altvar = 0

    tasks = []
    for i in range(len(chunks)):
        tasks.append(count_split(cookies[altvar], chunks[i]))
        altvar += 1
        if altvar == len(cookies):
            altvar = 0
    await asyncio.gather(*tasks)

asyncio.run(main())